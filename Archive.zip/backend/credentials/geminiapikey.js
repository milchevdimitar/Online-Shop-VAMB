const GEMINI_API = "AIzaSyCC8JLDzyG-wfoAe0_FZ6cL3ryZHoh0RVQ"

export default GEMINI_API;