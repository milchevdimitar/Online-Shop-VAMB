curl "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash-exp:generateContent?key=AIzaSyCC8JLDzyG-wfoAe0_FZ6cL3ryZHoh0RVQ" \
-H 'Content-Type: application/json' \
-X POST \
-d '{
  "contents": [{
    "parts":[{"text": "Where is the city Sofia Located ?"}]
    }]
   }'